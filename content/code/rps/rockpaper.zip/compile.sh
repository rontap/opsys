gcc -pedantic -Wall player.c -o player
gcc -pedantic -Wall tournament.c -o tournament
gcc -pedantic -Wall runtime.c -o runtime